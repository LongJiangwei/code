import numpy as np
from itertools import product

def base10():
    Hgate = np.array([[1,1], [1,-1]])/np.sqrt(2)
    HconjT = Hgate.T.conj()
    tao = (np.sqrt(5)-1)/2
    tao_sqrt = np.sqrt(tao)

    A = np.array([[np.exp(-4/5*np.pi*1j), 0],
                    [0, np.exp(3/5*np.pi*1j)]])
                                
    B = np.array([[-tao*np.exp(-np.pi*1j/5),tao_sqrt*np.exp(-3/5*np.pi*1j)], 
                    [tao_sqrt*np.exp(-3/5*np.pi*1j),  -tao]])

    C = np.linalg.inv(A)

    D = np.linalg.inv(B)

    matrix_dict = dict(A=A, B=B, C=C, D=D)
    matrices = ("A", "B", "C", "D")
    dist_H = lambda V : np.sqrt(1 - np.abs(np.trace(HconjT@V))/2)

    max_fit, max_fit_list = 1, []
    counter = 0
    for i in product(matrices, repeat=10):
        a_seq = "".join(i)
        if "AC" in a_seq or "CA" in a_seq or "BD" in a_seq or "DB" in a_seq:
            continue
        result = np.eye(2, dtype=np.complex128)
        for achar in a_seq:
            result = result @ matrix_dict[achar]
        fitness = dist_H(result)
        delta = fitness - max_fit
        if np.abs(delta)<1e-11:
            counter += 1
            max_fit_list.append((a_seq))
            continue
        if delta < 0:
            counter = 0
            # print(fitness)
            max_fit_list.clear()
            max_fit_list.append((a_seq))
            max_fit = fitness 
            
    return max_fit_list