import numpy as np
from random import randint, sample
from . import func

class Genertor(object):
    def __init__(self, parents:list, 
                 mutation_rate=0.1, max_mutation_points=1, module="H"):
        self.L = len(parents[0][0])
        self.parents = [i[0] for i in parents]
        self.mutation_rate = mutation_rate
        self.max_mutation_points = max_mutation_points
        self.children = parents[:]
        self.children_name = self.parents[:]
        self.module = module

        
    def launch(self):
        i = 1
        while i != 1501 :
            father, mather = sample(self.parents, 2)
            child1, child2 = self.crossover_and_mutation(father, mather)
            if child1 in self.children_name or child2 in self.children_name:
                continue
            i+=1
            self.children_name.append(child1)
            self.children_name.append(child2)
            self.children.append(self.calculate_fitness(child1, self.module))
            self.children.append(self.calculate_fitness(child2, self.module))
        self.children.sort(key=lambda x:x[1], reverse=True)

        
    def crossover_and_mutation(self, father:list, mather:list):
        n = randint(1, self.L-1)
        child1 = father[:n] + mather[n:]
        child2 = mather[:n] + father[n:]
        func.mutation(child1, self.L, self.mutation_rate, self.max_mutation_points)
        func.mutation(child2, self.L, self.mutation_rate, self.max_mutation_points)
        
        return  child1, child2
        
        
    def calculate_fitness(self, sequence, module):
        fitness = func.fitness(sequence, module)
        return (sequence, fitness)
    
if __name__ == "__main__":
    print()
    
    
        
        
        