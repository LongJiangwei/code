import numpy as np
from . import parameters
import random

f_H = lambda V : np.abs(np.trace(parameters.HconjT@V))
f_X = lambda V : np.abs(np.trace(parameters.XconjT@V))
f_T = lambda V : np.abs(np.trace(parameters.TconjT@V))

f_V1 = lambda V : np.abs(np.trace(parameters.V1Tconj@V))
f_W1 = lambda V : np.abs(np.trace(parameters.W1Tconj@V))

def fitness(string:list, module:str) -> float:
    V = np.eye(2)
    for i in string:
        V = V @ parameters.matrix_dict[i]
    
    if module=="H":
        return f_H(V)
    elif module=="T":
        return f_T(V)
    elif module=="X":
        return f_X(V)
    elif module == "V1":
        return f_V1(V)
    elif module == "W1":
        return f_W1(V)
    else:
        return 


def mutation(sequence:list, L:int, rate, tot_numbers):
    if random.choices((True, False), weights=(rate, 1-rate), k=1)[0]:
        if tot_numbers > 1:
            points_num = random.randint(1, tot_numbers)
        else:
            points_num = 1
        points = random.sample(range(L), points_num)
        for index in points:
            achar = random.choice(parameters.dict_for_mutation[sequence[index]])
            sequence[index] = achar
            
            
def a_good_dots(num, former_char):
    achar =  random.choice(parameters.dict_for_gooddots[former_char])
    if num > 1:
        num -= 1
        return former_char + a_good_dots(num, achar)
    else:
        return former_char
           
def good_dots(n, L):
    counter = 0
    return_list = []
    while counter < n:
        init_char = random.choice(parameters.all_matrix)
        a_good_sequence = a_good_dots(L, init_char)
        if a_good_sequence in return_list:
            continue
        return_list.append(a_good_sequence)
        counter += 1
        
    for sequence in return_list:
        yield list(sequence) 
        

def select_children(children, all, best):
    best_list = children[:best]
    rest = all - best
    rest_list = random.sample(children[best:], rest)
    return best_list + rest_list