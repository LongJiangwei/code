import numpy as np

Hgate = np.array([[1,1], [1,-1]])/np.sqrt(2)
Xgate = np.array([[0, 1], [1, 0]])
Tgate = np.array([[1, 0], [0, np.exp(1j*np.pi/4)]])
HconjT = Hgate.conj().T
XconjT = Xgate.conj().T
TconjT = Tgate.conj().T

tao = (np.sqrt(5)-1)/2

A = np.array([[np.exp(-4j*np.pi/5),0],
              [0,np.exp(3j*np.pi/5)]])
                            
B = np.array([[-tao*np.exp(-1j*np.pi/5),np.sqrt(tao)*np.exp(-3j*np.pi/5)],
              [np.sqrt(tao)*np.exp(-3j*np.pi/5),-tao]])


C = np.linalg.inv(A)

D = np.linalg.inv(B)

matrix_dict = dict(A=A, B=B, C=C, D=D)

dict_for_mutation = {
    "A": ["B", "C", "D"],
    "B": ["A", "C", "D"],
    "C": ["A", "B", "D"], 
    "D": ["A", "B", "C"],
}

dict_for_gooddots = {
    "A": ["A", "B", "D"],
    "B": ["A", "B", "C"],
    "C": ["B", "C", "D"], 
    "D": ["A", "C", "D"],
}

all_matrix = ["A", "B", "C", "D"]



V1 = np.array([[0.9992816539752014+0.008817489541584567j, -0.03063098304702793-0.020498067819736412j], 
                [0.030630983047027938-0.02049806781973642j, 0.9992816539752014-0.008817489541584567j]])

W1 = np.array([[0.9992816539752014+0.0003557739140841454j, 0.021146253171444054-0.03144654878229135j], 
           [-0.021146253171444043-0.03144654878229135j, 0.9992816539752014-0.00035577391408408987j]])
 
V1Tconj = V1.T.conj()
W1Tconj = W1.T.conj()
